//
//  NSObject+property.h
//  runtime
//
//  Created by duxiaoqiang on 16/6/13.
//  Copyright © 2016年 professional. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (property)
+ (void)createProperty:(NSDictionary *)dict;
@end
