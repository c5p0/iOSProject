//
//  MyTextView.h
//  QQ平滑
//
//  Created by duxiaoqiang on 16/9/2.
//  Copyright © 2016年 professional. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTextView : UITextView
@property (nonatomic,assign) NSInteger kMaxLength; // 最多允许输入文字长度
@end
