//
//  XMGRemoteResourceLoaderDelegate.h
//  播放器
//
//  Created by 小码哥 on 2017/1/14.
//  Copyright © 2017年 xmg. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface XMGRemoteResourceLoaderDelegate : NSObject<AVAssetResourceLoaderDelegate>

@end
