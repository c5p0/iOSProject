//
//  CGCalendarCollectionViewCell.h
//  SecondMenuDemo
//
//  Created by duxiaoqiang on 2017/5/16.
//  Copyright © 2017年 professional. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CGCalendarCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *showNumLabel;
@property (weak, nonatomic) IBOutlet UIImageView *showBackImage;

@end
