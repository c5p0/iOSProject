//
//  XMGDanmuModel.m
//  弹幕
//
//  Created by 小码哥 on 2017/2/19.
//  Copyright © 2017年 xmg. All rights reserved.
//

#import "XMGDanmuModel.h"

@implementation XMGDanmuModel

@end
