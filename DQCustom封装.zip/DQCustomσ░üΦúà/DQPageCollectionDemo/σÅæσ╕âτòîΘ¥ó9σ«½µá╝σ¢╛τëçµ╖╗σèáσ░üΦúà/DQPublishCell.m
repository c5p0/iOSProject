//
//  DQPublishCell.m
//  DQCustom封装
//
//  Created by duxiaoqiang on 2017/5/24.
//  Copyright © 2017年 professional. All rights reserved.
//

#import "DQPublishCell.h"

@implementation DQPublishCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
