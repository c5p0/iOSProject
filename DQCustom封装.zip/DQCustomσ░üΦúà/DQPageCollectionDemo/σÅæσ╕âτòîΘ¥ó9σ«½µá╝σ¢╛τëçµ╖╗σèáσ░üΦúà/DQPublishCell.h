//
//  DQPublishCell.h
//  DQCustom封装
//
//  Created by duxiaoqiang on 2017/5/24.
//  Copyright © 2017年 professional. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DQPublishCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *showImageVIew;

@end
